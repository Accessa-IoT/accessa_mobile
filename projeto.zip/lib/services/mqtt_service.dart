
import 'dart:async';
import 'dart:io';
import 'package:mqtt_client/mqtt_client.dart';
import 'package:mqtt_client/mqtt_server_client.dart';
import 'mqtt_config.dart';

class MqttService {
  MqttServerClient? _client;
  Future<void>? _connecting; // evita conexões paralelas
  final _messageCtrl = StreamController<MqttReceivedMessage<MqttMessage>>.broadcast();

  Stream<MqttReceivedMessage<MqttMessage>> get messages => _messageCtrl.stream;
  bool get isConnected => _client?.connectionStatus?.state == MqttConnectionState.connected;

  Future<void> connect() async {
    if (isConnected) return;
    if (_connecting != null) {
      return _connecting;
    }

    if (MqttConfig.host.contains('YOUR-CLUSTER') || MqttConfig.password == 'REPLACE_ME') {
      throw Exception('Configure MqttConfig.host e MqttConfig.password com os dados reais do HiveMQ Cloud.');
    }

    final client = MqttServerClient.withPort(MqttConfig.host, MqttConfig.clientId(), MqttConfig.port);
    client.logging(on: false);
    client.secure = true; // TLS (porta 8883)
    client.keepAlivePeriod = 30;
    client.onDisconnected = () { };
    client.onConnected = () { };
    client.securityContext = SecurityContext.defaultContext;

    final connMess = MqttConnectMessage()
        .withClientIdentifier(MqttConfig.clientId())
        .authenticateAs(MqttConfig.username, MqttConfig.password)
        .withWillQos(MqttQos.atLeastOnce);
    client.connectionMessage = connMess;

    _connecting = () async {
      try {
        await client.connect();
        client.updates?.listen((events) {
          for (final e in events) {
            _messageCtrl.add(e);
          }
        });
        _client = client;
      } on Exception catch (e) {
        client.disconnect();
        rethrow;
      } finally {
        _connecting = null;
      }
    }();

    return _connecting;
  }

  Future<void> disconnect() async {
    _client?.disconnect();
    _client = null;
  }

  Future<void> subscribe(String topic, {MqttQos qos = MqttQos.atLeastOnce}) async {
    if (!isConnected) await connect();
    _client?.subscribe(topic, qos);
  }

  Future<void> unsubscribe(String topic) async {
    _client?.unsubscribe(topic);
  }

  Future<void> publishString(String topic, String payload, {MqttQos qos = MqttQos.atLeastOnce, bool retain = false}) async {
    if (!isConnected) await connect();
    final builder = MqttClientPayloadBuilder();
    builder.addString(payload);
    _client?.publishMessage(topic, qos, builder.payload!, retain: retain);
  }
}
