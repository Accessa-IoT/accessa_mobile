
# Atividade 3 – Implementação de IoT no Projeto (Entrega)

**Broker escolhido:** HiveMQ Cloud (Serverless Free).  
**Justificativa:** plano gratuito suficiente para desenvolvimento (até 100 conexões e 10 GB/mês), suporte aos protocolos MQTT 3.1/3.1.1/5.0, TLS/SSL nativo (porta 8883) e cliente Web para testes. Permite criar *users* distintos (prod/app/visita) e usar WebSockets quando necessário.

## Configuração realizada
- **Cluster:** `YOUR-CLUSTER.s1.eu.hivemq.cloud` (substituir pelo seu id real)
- **Porta TLS:** `8883` (MQTT seguro)
- **Usuário de app:** `app_accessa`
- **Autenticação:** usuário/senha (Access Management)
- **Conexão do app:** pacote `mqtt_client` (Flutter/Dart) com TLS habilitado

## Estrutura de Tópicos
Base: `accessa/`

- `accessa/<deviceId>/status` — *online|offline*
- `accessa/<deviceId>/sensors/temperature` — JSON `{"ts": "...","value": <°C>}`
- `accessa/<deviceId>/sensors/humidity` — JSON `{"ts": "...","value": < % >}`
- `accessa/<deviceId>/sensors/motion` — JSON `{"ts": "...","value": true|false}`
- `accessa/<deviceId>/actuators/led/set` — *on|off*
- `accessa/<deviceId>/actuators/led/state` — *on|off* (eco do dispositivo)

Convenções:
- JSON com `ts` (ISO-8601) sempre que houver medidas.
- QoS 1 para telemetria; **retain** apenas em `.../state` e `.../status`.

## Elementos IoT (simulados)
- **Sensores:** temperatura, umidade, movimento.
- **Atuador:** LED virtual (tela do app) com comando por tópico `.../led/set`.
- O app publica telemetria e assina `accessa/#` para visualizar mensagens.

## Link público / como acessar
- **WebClient HiveMQ (sua organização):** (abra o *Web Client* do seu cluster e gere um usuário *viewer*).  
  - Host: `YOUR-CLUSTER.s1.eu.hivemq.cloud`  
  - Porta: `8883` (ou `8884` para WebSocket TLS, se habilitado)  
  - User: `viewer` (somente leitura) — *criar no Access Management*  
  - Topic de teste: `accessa/#` (QoS 1)

> Se preferir, compartilhe um vídeo curto mostrando publicação/recepção pelo app e pelo WebClient.

## Como aplicar no app
1. Adicione ao `pubspec.yaml`:
   ```yaml
   dependencies:
     mqtt_client: ^10.2.0
   ```
2. Copie os arquivos:
   - `services/mqtt_config.dart`
   - `services/mqtt_service.dart`
   - `screens/mqtt/mqtt_screen.dart`
3. Atualize `main.dart` para incluir a rota **/mqtt** ou um botão "MQTT" no *Home*.
4. Preencha `MqttConfig.host` e `MqttConfig.password` com os dados do seu cluster.
5. Rode: `flutter pub get` e teste.

## Tópicos de exemplo para teste rápido
- Publish → `accessa/demo` com payload `{"ts":"2025-10-27T22:05:51.093593","hello":"world"}`
- Subscribe → `accessa/#`

---

**Participantes que contribuíram:** (Hagliberto Alves de Oliveira)  
**Data:** 2025-10-27
